package com.example.whatsappstickers;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.BaseColumns;

import java.io.IOException;

/** ContentProvider used by WhatsApp to read the sticker pack metadata and files. */
public class StickerContentProvider extends ContentProvider {

    public static final String AUTHORITY =
            "com.example.whatsappstickers.stickercontentprovider";
    private static final String PACK_ID = "dirty_trap_pack";
    private static final String PACK_NAME = "Dirty Trap";
    private static final String PACK_PUBLISHER = "Dirty Trap";
    private static final String ASSET_PATH = "stickers_asset/" + PACK_ID + "/";

    private static final String[] STICKERS = {
            "01_nu_vse_ya_bidelsya.webp",
            "02_vse_ravno_bidelsya.webp",
            "03_davay_ne_budem.webp",
            "04_krutyak.webp",
            "05_znaesh_chto.webp",
            "06_ne_nachinay.webp",
            "07_idite_v_zhopu.webp"
    };

    @Override public boolean onCreate() { return true; }

    @Override public String getType(Uri uri) {
        return "image/webp";
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        String path = uri.getPath();
        if (path == null) path = "";

        if ("/metadata".equals(path) || path.startsWith("/metadata/")) {
            return metadataCursor();
        }

        if ("/stickers/".equals(path) || path.startsWith("/stickers/")) {
            String identifier = uri.getLastPathSegment();
            if (PACK_ID.equals(identifier)) {
                return stickersCursor(projection);
            }
        }

        return new MatrixCursor(projection != null ? projection
                : new String[]{BaseColumns._ID, "image_file_name", "emojis"});
    }

    private Cursor metadataCursor() {
        MatrixCursor cursor = new MatrixCursor(new String[]{
                "sticker_pack_identifier",
                "sticker_pack_name",
                "sticker_pack_publisher",
                "sticker_pack_icon",
                "android_play_store_link",
                "ios_app_store_link",
                "publisher_email",
                "publisher_website",
                "privacy_policy_website",
                "license_agreement_website",
                "image_data_version",
                "avoid_cache",
                "animated_sticker_pack"
        });
        cursor.addRow(new Object[]{
                PACK_ID, PACK_NAME, PACK_PUBLISHER, "tray_icon.webp",
                "", "", "", "", "", "", "1", 0, 1
        });
        return cursor;
    }

    private Cursor stickersCursor(String[] projection) {
        String[] columns = projection != null ? projection : new String[]{
                BaseColumns._ID, "image_file_name", "emojis", "accessibility_text"
        };
        MatrixCursor cursor = new MatrixCursor(columns);
        for (int i = 0; i < STICKERS.length; i++) {
            Object[] row = new Object[columns.length];
            for (int j = 0; j < columns.length; j++) {
                switch (columns[j]) {
                    case BaseColumns._ID: row[j] = i; break;
                    case "image_file_name": row[j] = STICKERS[i]; break;
                    case "emojis": row[j] = "😀"; break;
                    case "accessibility_text": row[j] = "Dirty Trap sticker"; break;
                    default: row[j] = null;
                }
            }
            cursor.addRow(row);
        }
        return cursor;
    }

    @Override
    public AssetFileDescriptor openAssetFile(Uri uri, String mode) throws IOException {
        String path = uri.getPath();
        if (path == null) throw new IOException("Unknown sticker URI: " + uri);

        // Official WhatsApp URI: /stickers_asset/<pack_identifier>/<file>
        String prefix = "/stickers_asset/" + PACK_ID + "/";
        if (path.startsWith(prefix)) {
            String fileName = path.substring(prefix.length());
            for (String sticker : STICKERS) {
                if (sticker.equals(fileName)) {
                    return getContext().getAssets().openFd(ASSET_PATH + fileName);
                }
            }
        }

        throw new IOException("Unknown sticker URI: " + uri);
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws IOException {
        AssetFileDescriptor afd = openAssetFile(uri, mode);
        return afd.getParcelFileDescriptor();
    }

    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
}
