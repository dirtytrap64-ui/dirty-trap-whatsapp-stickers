package com.example.whatsappstickers;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PACK_ID = "dirty_trap_pack";
    private static final String AUTHORITY =
            "com.example.whatsappstickers.stickercontentprovider";
    private static final String PACK_NAME = "Dirty Trap";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView title = new TextView(this);
        title.setText("Dirty Trap — анимированные стикеры\\n\\nНажмите кнопку ниже, чтобы добавить набор в WhatsApp.");
        title.setTextSize(18);
        title.setPadding(48, 80, 48, 32);

        Button add = new Button(this);
        add.setText("Добавить в WhatsApp");
        add.setOnClickListener(v -> addToWhatsApp());

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.addView(title, new android.widget.LinearLayout.LayoutParams(-1, 0, 1));
        layout.addView(add, new android.widget.LinearLayout.LayoutParams(-1, -2));
        setContentView(layout);
    }

    private void addToWhatsApp() {
        try {
            Intent intent = new Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK");
            intent.putExtra("sticker_pack_id", PACK_ID);
            intent.putExtra("sticker_pack_authority", AUTHORITY);
            intent.putExtra("sticker_pack_name", PACK_NAME);
            startActivityForResult(intent, 200);
        } catch (Exception e) {
            Toast.makeText(this,
                    "WhatsApp не найден или не поддерживает добавление этого набора.",
                    Toast.LENGTH_LONG).show();
        }
    }
}
