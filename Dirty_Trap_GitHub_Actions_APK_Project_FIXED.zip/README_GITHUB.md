# Dirty Trap — GitHub build

This repository can build the Android APK using GitHub Actions.

1. Open **Actions**.
2. Select **Build Dirty Trap APK**.
3. Choose **Run workflow** on `main`.
4. After the run succeeds, open the run and download the artifact **Dirty-Trap-WhatsApp-Stickers-APK**.

The project is built directly from the repository; no ZIP extraction step is required.
