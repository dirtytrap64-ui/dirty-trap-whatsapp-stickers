# Dirty Trap — WhatsApp animated stickers

Android app for adding the Dirty Trap animated sticker pack to WhatsApp.

## Build

```bash
gradle :app:assembleDebug
```

The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

The GitHub Actions workflow can build the APK without Android Studio.
