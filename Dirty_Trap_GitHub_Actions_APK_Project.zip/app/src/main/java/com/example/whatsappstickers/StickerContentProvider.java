package com.example.whatsappstickers;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.BaseColumns;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class StickerContentProvider extends ContentProvider {

    public static final String AUTHORITY = "com.example.whatsappstickers.stickercontentprovider";
    private static final String PACK_ID = "dirty_trap_pack";
    private static final String ASSET_PATH = "stickers_asset/" + PACK_ID + "/";

    private static final String[] STICKERS = {
        "01_nu_vse_ya_bidelsya.webp",
        "02_vse_ravno_bidelsya.webp",
        "03_davay_ne_budem.webp",
        "04_krutyak.webp",
        "05_znaesh_chto.webp",
        "06_ne_nachinay.webp",
        "07_idite_v_zhopu.webp"
    };

    @Override public boolean onCreate() { return true; }

    @Override public String getType(Uri uri) {
        return "image/webp";
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection,
                                  String[] selectionArgs, String sortOrder) {
        String[] columns = projection != null ? projection : new String[] {
            BaseColumns._ID, "image_file_name", "emojis"
        };

        MatrixCursor cursor = new MatrixCursor(columns);

        if (uri.getPathSegments().size() == 1 && "metadata".equals(uri.getPathSegments().get(0))) {
            MatrixCursor metadata = new MatrixCursor(new String[] {
                "sticker_pack_id", "sticker_pack_name", "sticker_pack_publisher",
                "sticker_pack_icon", "android_play_store_link",
                "ios_app_store_link", "publisher_email", "publisher_website",
                "privacy_policy_website", "license_agreement_website",
                "image_data_version", "avoid_cache", "animated_sticker_pack"
            });
            metadata.addRow(new Object[] {
                PACK_ID, "Dirty Trap", "Dirty Trap", "tray_icon.webp",
                "", "", "", "", "", "", "1", 0, 1
            });
            return metadata;
        }

        if (uri.getPathSegments().size() == 2 &&
            "stickers".equals(uri.getPathSegments().get(0))) {
            int index = Integer.parseInt(uri.getPathSegments().get(1));
            if (index >= 0 && index < STICKERS.length) {
                cursor.addRow(buildRow(columns, index));
            }
        } else if (uri.getPathSegments().size() == 1 &&
                   "stickers".equals(uri.getPathSegments().get(0))) {
            for (int i = 0; i < STICKERS.length; i++) {
                cursor.addRow(buildRow(columns, i));
            }
        }
        return cursor;
    }

    private Object[] buildRow(String[] columns, int index) {
        Object[] row = new Object[columns.length];
        for (int i = 0; i < columns.length; i++) {
            switch (columns[i]) {
                case BaseColumns._ID: row[i] = index; break;
                case "image_file_name": row[i] = STICKERS[index]; break;
                case "emojis": row[i] = "😀"; break;
                default: row[i] = null;
            }
        }
        return row;
    }

    @Override public AssetFileDescriptor openAssetFile(Uri uri, String mode) throws IOException {
        if (uri.getPathSegments().size() >= 2 &&
            "stickers".equals(uri.getPathSegments().get(0))) {
            int index = Integer.parseInt(uri.getPathSegments().get(1));
            if (index >= 0 && index < STICKERS.length) {
                return getContext().getAssets().openFd(ASSET_PATH + STICKERS[index]);
            }
        }
        throw new IOException("Unknown sticker URI: " + uri);
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws IOException {
        AssetFileDescriptor afd = openAssetFile(uri, mode);
        return afd.getParcelFileDescriptor();
    }

    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
}
