# Dirty Trap WhatsApp — сборка APK с телефона

## Вариант без Android Studio

Этот проект содержит GitHub Actions workflow. GitHub соберёт APK на своих серверах.

### 1. Создай репозиторий
На GitHub создай новый репозиторий, например:
`dirty-trap-whatsapp-stickers`

### 2. Загрузи содержимое этой папки
В GitHub можно выбрать **Add file → Upload files** и загрузить все файлы проекта.

Важно: загружай именно содержимое проекта, чтобы `.github/workflows/build.yml` оказался по этому пути.

### 3. Запусти сборку
Открой вкладку **Actions** → **Build APK** → **Run workflow**.

### 4. Скачай APK
После завершения сборки открой успешный запуск workflow.
Внизу страницы будет **Artifacts** → `Dirty-Trap-WhatsApp-Stickers-APK`.

Скачай ZIP, распакуй его и получишь `app-debug.apk`.

### 5. Установи на телефон
Открой APK и установи приложение. Затем:
**Dirty Trap Stickers → Добавить в WhatsApp**.

## Требования
- аккаунт GitHub;
- браузер на телефоне;
- установленный WhatsApp;
- разрешение Android на установку приложения из браузера/файлового менеджера, если система его запросит.

## Примечание
GitHub Actions выполняет сборку в облаке, поэтому Android Studio на телефоне не нужна.
