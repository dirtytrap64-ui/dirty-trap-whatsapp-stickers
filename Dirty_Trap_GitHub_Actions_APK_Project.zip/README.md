# Dirty Trap — WhatsApp Animated Sticker Pack

Android Studio project for an animated WhatsApp sticker pack.

## What is included
- 7 animated WebP stickers, 512×512, transparent background.
- Native Android app with an **«Добавить в WhatsApp»** button.
- WhatsApp sticker ContentProvider.
- Animated sticker pack metadata.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Use JDK 17.
4. Build → Build APK(s).
5. Install the generated APK on an Android phone.
6. Open **Dirty Trap Stickers**.
7. Tap **«Добавить в WhatsApp»** and confirm in WhatsApp.

## Important
The app does not send anything to a server. The stickers are bundled in the APK.
WhatsApp must be installed and support animated sticker packs on the target device.
